<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompanyProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company_projects', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('area');
            $table->string('height');
            $table->string('room');
            $table->string('bathroom');
            $table->string('Expected_duration');
            $table->text('description');
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('unity_id')->constrained('unities')->cascadeOnDelete();
            $table->foreignId('architectural_id')->constrained('architecturals')->cascadeOnDelete();
            $table->foreignId('expected_budget_id')->constrained('expected_budgets')->cascadeOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('company_projects');
    }
}
