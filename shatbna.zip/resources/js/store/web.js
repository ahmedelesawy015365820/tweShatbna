import { createStore } from 'vuex';
import auth from './web/auth';

const store = createStore({
    state () {
        return {

        }
    },
    getters:{
    },
    mutations: {

    },
    actions:{

    },
    modules:{
        auth
    }
});

export default store;
