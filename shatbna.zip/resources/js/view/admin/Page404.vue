<template>
<div class="page-wrapper">
    <div class="row justify-content-center  align-items-center high">
        <!-- Page Not Found -->
        <div class="empty-content text-center">
            <img src="../../assets/img/404.png" alt="logo" class="img-fluid">
            <h2>Page not <span class="orange-text">found</span></h2>
            <p>Oops! Looks like you followed a bad link.</p>
            <p>If you think this is a problem with us, please tell us.</p>
        </div>
        <!-- / Page Not Found -->
    </div>
</div>
</template>

<script>

export default {

}
</script>

<style  scoped>
.page-wrapper {
    width: 100%;
}

.high {
    height: 100vh;
}

.courses-btn {
    background: #131135;
    border-radius: 130px;
    font-weight: bold;
    padding: 12px 39px;
    color: #fff;
    text-transform: uppercase;
}

</style>
