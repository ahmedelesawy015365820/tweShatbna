<?php

return [

    "approved" => "Your account has not been approved",
    "forget" => "Your Email/Password is wrong"
];
